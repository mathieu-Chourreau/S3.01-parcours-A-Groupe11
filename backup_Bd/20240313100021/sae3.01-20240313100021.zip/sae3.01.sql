﻿-- MySQL dump 10.13  Distrib 8.2.0, for Win64 (x86_64)
--
-- Host: localhost    Database: sae3.01
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sae3.01`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sae3.01` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `sae3.01`;

--
-- Table structure for table `appartenirrc`
--

DROP TABLE IF EXISTS `appartenirrc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appartenirrc` (
  `identifiantR` int NOT NULL,
  `identifiantC` int NOT NULL,
  PRIMARY KEY (`identifiantR`,`identifiantC`),
  KEY `identifiantC` (`identifiantC`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appartenirrc`
--

LOCK TABLES `appartenirrc` WRITE;
/*!40000 ALTER TABLE `appartenirrc` DISABLE KEYS */;
INSERT INTO `appartenirrc` VALUES (1,1),(2,6),(3,6),(4,3),(5,1),(6,6),(7,3),(8,1),(9,3),(10,3),(11,3),(12,1),(13,6),(14,6),(15,3),(16,1),(17,1),(18,1),(19,1),(20,3),(21,1),(22,6),(23,5),(24,6),(25,6),(26,1);
/*!40000 ALTER TABLE `appartenirrc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avis`
--

DROP TABLE IF EXISTS `avis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avis` (
  `identifiant` int NOT NULL,
  `note` decimal(2,1) NOT NULL,
  `commentaire` varchar(100) DEFAULT NULL,
  `date_publication` date NOT NULL,
  `identifiantU` int NOT NULL,
  `identifiantR` int NOT NULL,
  PRIMARY KEY (`identifiant`),
  KEY `identifiantR` (`identifiantR`),
  KEY `identifiantU` (`identifiantU`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avis`
--

LOCK TABLES `avis` WRITE;
/*!40000 ALTER TABLE `avis` DISABLE KEYS */;
INSERT INTO `avis` VALUES (1,4.7,'La cuisson du steak ├®tait parfaite','0000-00-00',1,4),(2,3.5,'Le curry ├®tait un peu trop ├®pic├® pour moi, mais le poulet ├®tait bien cuit.','0000-00-00',2,5),(3,4.2,'Une salade fra├«che et d├®licieuse. Les saveurs se marient parfaitement.','0000-00-00',3,6),(4,4.8,'Le saumon ├®tait incroyablement savoureux. La sauce ├á la cr├¿me fra├«che ├®tait divine.','0000-00-00',4,7),(5,4.5,'Le risotto ├®tait cr├®meux et d├®licieux. Les champignons ajoutent une belle texture.','0000-00-00',1,8),(6,4.0,'Le tartare de b┼ôuf ├®tait frais et d├®licieux. Un r├®gal pour les amateurs de viande crue.','0000-00-00',2,9),(7,3.8,'Les p├ótes ├®taient d├®licieuses, mais la sauce ├®tait un peu trop riche pour moi.','0000-00-00',3,10),(8,4.6,'Les crevettes ├®taient parfaitement grill├®es et lajout de citron parfait.','0000-00-00',4,11),(9,3.9,'Un bon curry v├®g├®tarien, mais je pense quil aurait pu ├¬tre un peu plus ├®pic├®.','0000-00-00',1,12),(10,4.4,'Une pizza simple mais d├®licieuse. La cro├╗te ├®tait parfaite.','0000-00-00',2,13);
/*!40000 ALTER TABLE `avis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avoir`
--

DROP TABLE IF EXISTS `avoir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avoir` (
  `identifiantV` int NOT NULL,
  `identifiantL` int NOT NULL,
  PRIMARY KEY (`identifiantV`,`identifiantL`),
  KEY `identifiantL` (`identifiantL`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avoir`
--

LOCK TABLES `avoir` WRITE;
/*!40000 ALTER TABLE `avoir` DISABLE KEYS */;
INSERT INTO `avoir` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1);
/*!40000 ALTER TABLE `avoir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorieingredient`
--

DROP TABLE IF EXISTS `categorieingredient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorieingredient` (
  `identifiant` int NOT NULL,
  `categorie` varchar(30) NOT NULL,
  PRIMARY KEY (`identifiant`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorieingredient`
--

LOCK TABLES `categorieingredient` WRITE;
/*!40000 ALTER TABLE `categorieingredient` DISABLE KEYS */;
INSERT INTO `categorieingredient` VALUES (1,'Viande rouge'),(2,'Viande blanche'),(3,'Legume'),(4,'Poisson'),(5,'Feculent'),(6,'Produit laitier'),(7,'Huile'),(8,'Epice');
/*!40000 ALTER TABLE `categorieingredient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorierecette`
--

DROP TABLE IF EXISTS `categorierecette`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorierecette` (
  `identifiant` int NOT NULL,
  `gout` varchar(10) NOT NULL,
  PRIMARY KEY (`identifiant`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorierecette`
--

LOCK TABLES `categorierecette` WRITE;
/*!40000 ALTER TABLE `categorierecette` DISABLE KEYS */;
INSERT INTO `categorierecette` VALUES (1,'Sal├®'),(2,'Sucr├®'),(3,'├ëpic├®'),(4,'Amer'),(5,'Acide'),(6,'V├®g├®tarien');
/*!40000 ALTER TABLE `categorierecette` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contenir`
--

DROP TABLE IF EXISTS `contenir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contenir` (
  `Ingredient_id` varchar(70) NOT NULL,
  `Recette_id` int NOT NULL,
  `quantite` int NOT NULL,
  PRIMARY KEY (`Ingredient_id`,`Recette_id`),
  KEY `Recette_id` (`Recette_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contenir`
--

LOCK TABLES `contenir` WRITE;
/*!40000 ALTER TABLE `contenir` DISABLE KEYS */;
INSERT INTO `contenir` VALUES ('Saumon',7,250),('Herbes de Provence',6,10),('Huile d olive',6,5),('Feta',6,15),('Concombre',6,15),('Tomate',6,15),('Salade',6,140),('Riz',5,200),('Curry',5,10),('Blanc de poulet',5,290),('Steak de b┼ôuf',11,300),('Lardons',4,130),('Basilic',4,20),('Mozzarella',4,50),('Tomate',4,50),('Pate a pizza',4,150),('Paprika',3,100),('Mozzarella',3,100),('Riz',3,300),('Curry',3,50),('Curry',2,30),('Ail',2,20),('Crevettes',2,250),('Sel',1,5),('Poivre',1,5),('Creme',1,50),('Parmesan',1,50),('Lardons',1,150),('Pates',1,200),('Aneth',7,30),('Riz',2,150),('Champignon',2,100),('Parmesan',2,50),('Tartare de b┼ôuf',2,150),('Pain complet',2,50),('Cote de porc',10,200),('Pommes de terre',10,100),('Creme',7,50),('P├ótes',12,250),('Sauce Carbonara',12,150),('Parmesan r├óp├®',12,30),('┼Æufs',13,4),('L├®gumes vari├®s',13,200),('Sel',13,5),('Poivre',13,5),('Riz',14,200),('L├®gumes saut├®s',14,150),('Sauce soja',14,20),('Poulet grill├®',15,150),('Pain pour sandwich',15,2),('L├®gumes frais',15,100),('P├ótes',16,250),('Sauce tomate',16,150),('Fromage r├óp├®',16,30),('P├ótes',17,250),('Lardons',17,150),('Sauce Carbonara',17,150),('Parmesan r├óp├®',17,30),('Sel',17,5),('Poivre',17,5),('Persil',17,10),('Poulet',18,200),('Tomates',18,150),('Concombres',18,100),('Vinaigrette',18,30),('Spaghetti',19,300),('Sauce Bolognaise',19,200),('Parmesan',19,30),('Poulet',20,250),('L├®gumes vari├®s',20,150),('Salsa',20,50),('Guacamole',20,50),('Riz',21,200),('L├®gumes saut├®s',21,150),('Jambon',21,100),('┼Æufs',21,3),('┼Æufs',22,4),('Fromage',22,50),('L├®gumes vari├®s',22,200),('Poulet grill├®',22,150),('Sauce au yaourt',22,30),('Poulet',23,300),('Citron',23,1),('Quinoa',24,150),('L├®gumes vari├®s',24,100),('Herbes',24,10),('Vinaigrette l├®g├¿re',24,30),('P├ótes',25,250),('Sauce Alfredo',25,150),('Brocolis',25,100),('Parmesan',25,30),('Poulet',26,400),('Lait de coco',26,200),('L├®gumes vari├®s',26,150),('Riz basmati',26,150);
/*!40000 ALTER TABLE `contenir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conteniravalider`
--

DROP TABLE IF EXISTS `conteniravalider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conteniravalider` (
  `Ingredient_id` varchar(70) NOT NULL,
  `Recette_id` int NOT NULL,
  `quantite` int NOT NULL,
  PRIMARY KEY (`Ingredient_id`,`Recette_id`),
  KEY `Recette_id` (`Recette_id`),
  CONSTRAINT `CheckQuantite` CHECK ((`quantite` > 0))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conteniravalider`
--

LOCK TABLES `conteniravalider` WRITE;
/*!40000 ALTER TABLE `conteniravalider` DISABLE KEYS */;
INSERT INTO `conteniravalider` VALUES ('Agneau',1,23),('Steak de b┼ôuf',1,5),('Steak de b┼ôuf',2,200),('Cote de porc',2,65),('Lardons',2,45);
/*!40000 ALTER TABLE `conteniravalider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingredient`
--

DROP TABLE IF EXISTS `ingredient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingredient` (
  `nom` varchar(70) NOT NULL,
  `prixKg` decimal(4,1) NOT NULL,
  `identifiantC` int NOT NULL,
  PRIMARY KEY (`nom`),
  KEY `identifiantC` (`identifiantC`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredient`
--

LOCK TABLES `ingredient` WRITE;
/*!40000 ALTER TABLE `ingredient` DISABLE KEYS */;
INSERT INTO `ingredient` VALUES ('Steak de b┼ôuf',13.0,1),('Cote de porc',9.5,1),('Agneau',15.0,1),('B┼ôuf hache',11.8,1),('Ragout de b┼ôuf',14.0,1),('Lardons',10.5,1),('Jarret de b┼ôuf',16.0,1),('Merguez',8.3,1),('Tartare de b┼ôuf',16.5,1),('B┼ôuf stroganoff',14.8,1),('Blanc de poulet',11.0,2),('Cuisse de poulet',8.5,2),('Dinde',10.0,2),('Escalope de dinde',8.0,2),('Poulet roti',11.3,2),('Aiguillettes de poulet',10.8,2),('Cuisses de dinde',9.8,2),('Filet de poulet',12.5,2),('Poitrine de poulet',10.3,2),('Poulet pane',9.0,2),('Tomate',2.3,3),('Carotte',1.2,3),('Courgette',2.5,3),('Brocoli',1.9,3),('Poivron',1.8,3),('Aubergine',3.0,3),('Oignon',1.3,3),('Champignon',3.5,3),('Salade',2.8,3),('Epinards',2.4,3),('Concombre',2.4,3),('Ail',2.0,3),('Saumon',16.0,4),('Crevettes',17.5,4),('Thon en conserve',5.8,4),('Filet de tilapia',10.0,4),('Morue',12.5,4),('Sardines',8.3,4),('Truite',14.8,4),('Bar',19.0,4),('Calamars',16.8,4),('Anchois',11.5,4),('Riz',3.7,5),('Pates',2.5,5),('Quinoa',5.0,5),('Pommes de terre',2.0,5),('Ble entier',3.3,5),('Couscous',2.8,5),('Orge',4.5,5),('Pain complet',2.2,5),('Lentilles',1.9,5),('Patates douces',3.0,5),('Pate a pizza',3.7,5),('Lait',3.0,6),('Fromage cheddar',5.5,6),('Yaourt nature',1.8,6),('Beurre',3.3,6),('Creme',2.5,6),('Fromage de chevre',7.0,6),('Parmesan',9.0,6),('Creme glacee vanille',4.8,6),('Feta',6.0,6),('Fromage suisse',6.5,6),('Mozzarella',5.0,6),('Huile d olive',6.5,7),('Huile de tournesol',5.3,7),('Huile de colza',5.8,7),('Cumin',3.0,8),('Paprika',1.8,8),('Curry',3.3,8),('Cannelle',2.5,8),('Gingembre',5.0,8),('Poivre',1.9,8),('Sel',1.6,8),('Herbes de Provence',40.0,8),('Aneth',1.5,8),('Basilic',1.5,8),('Sauce Carbonara',4.5,6),('Parmesan r├óp├®',15.0,6),('┼Æufs',2.5,2),('L├®gumes vari├®s',3.0,3),('L├®gumes saut├®s',4.0,3),('Sauce soja',20.0,7),('Poulet grill├®',11.0,2),('Pain pour sandwich',2.2,5),('L├®gumes frais',2.8,3),('Sauce tomate',5.0,3),('Fromage r├óp├®',10.0,6);
/*!40000 ALTER TABLE `ingredient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `langue`
--

DROP TABLE IF EXISTS `langue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `langue` (
  `identifiant` int NOT NULL,
  `libelle` varchar(10) NOT NULL,
  PRIMARY KEY (`identifiant`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `langue`
--

LOCK TABLES `langue` WRITE;
/*!40000 ALTER TABLE `langue` DISABLE KEYS */;
INSERT INTO `langue` VALUES (1,'Fran├ºais'),(2,'English');
/*!40000 ALTER TABLE `langue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recette`
--

DROP TABLE IF EXISTS `recette`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recette` (
  `identifiant` int NOT NULL,
  `nom` varchar(50) NOT NULL,
  `instruction` varchar(1000) NOT NULL,
  `temps_min_` int NOT NULL,
  `niveau_difficulte` varchar(10) NOT NULL,
  `grammage` int NOT NULL,
  `identifiantVideo` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`identifiant`),
  UNIQUE KEY `identifiantVideo` (`identifiantVideo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recette`
--

LOCK TABLES `recette` WRITE;
/*!40000 ALTER TABLE `recette` DISABLE KEYS */;
INSERT INTO `recette` VALUES (9,'Tartare de B┼ôuf','Pr├®parez un tartare de b┼ôuf en coupant finement le b┼ôuf, en ajoutant des condiments et en servant avec des toasts.',25,'Facile',200,7,'image/tartare-de-boeuf.jpg'),(7,'Saumon Grill├®','Faites griller des filets de saumon avec du citron et servez avec une sauce ├á base de cr├¿me fra├«che et daneth.',30,'Moyen',330,5,'image/pave-de-saumon-grille.jpg'),(2,'Risotto aux Champignons','Pr├®parez un d├®licieux risotto avec du riz, des champignons, du parmesan et du bouillon de l├®gumes.',35,'Moyen',300,6,'image/risotto-aux-champignons.jpg'),(4,'Pizza Margherita','Faites une pizza classique avec une p├óte ├á pizza, de la sauce tomate, de la mozzarella et du basilic.',25,'Facile',400,11,'image/pizza-margarita.jpg'),(11,'Steak de B┼ôuf Grill├®','Pr├®parez un steak de b┼ôuf et faites-le griller ├á la perfection. Assaisonnez avec du sel et du poivre selon votre go├╗t.',20,'Facile',300,2,'image/steak.jpg'),(5,'Poulet Curry','Cuisinez des morceaux de blanc de poulet avec du curry, des l├®gumes et du lait de coco. Servez avec du riz.',40,'Moyen',500,3,'image/poulet-curry.jpg'),(6,'Salade Grecque','Pr├®parez une salade fra├«che avec des tomates, concombres, olives, feta et assaisonnez avec de lhuile dolive et des herbes de Provence.',15,'Facile',200,4,'image/salade-grecque.jpg'),(3,'Curry V├®g├®tarien','Pr├®parez un curry v├®g├®tarien avec des l├®gumes, du lait de coco et du curry. Servez avec du riz.',40,'Moyen',500,10,'image/curry-vege.jpg'),(1,'P├ótes Carbonara','Des p├ótes cr├®meuses avec une sauce Carbonara riche et savoureuse.',20,'Facile',460,1,'image/pate-carbonara.jpg'),(8,'Crevettes Grill├®es au Curry','Faites griller des crevettes avec du citron et de lail pour une saveur d├®licieuse.',20,'Facile',300,9,'image/crevette-grille-au-curry.jpg'),(10,'Poulet-frite','Poulet avec des frites.',30,'Moyen',300,8,'image/poulet-frite.jpg'),(12,'P├ótes ├á la Carbonara Rapides','Cuisinez des p├ótes et m├®langez-les avec une sauce Carbonara pr├¬te ├á l emploi. Garnissez de parmesan.',15,'Facile',300,23,'image/pate-carbo-rapide'),(13,'Omelette aux L├®gumes','Battez des ┼ôufs, ajoutez des l├®gumes coup├®s en d├®s et faites cuire le tout dans une po├¬le. Simple et nutritif.',20,'Facile',250,24,'image/omelette-legume.jpg'),(14,'Riz Saut├® aux L├®gumes','Faites cuire du riz et m├®langez-le avec des l├®gumes saut├®s. Assaisonnez avec de la sauce soja pour plus de saveur.',25,'Facile',350,25,'image/riz-saute-legume.jpg'),(15,'Sandwich au Poulet Grill├®','Faites griller des morceaux de poulet, assemblez-les dans un sandwich avec des l├®gumes frais. Rapide et d├®licieux.',15,'Facile',200,26,'image/sandwitch-poulet.jpg'),(16,'P├ótes aux Tomates et Fromage','Cuisinez des p├ótes, ajoutez une sauce tomate et du fromage r├óp├®. Un repas simple mais savoureux.',20,'Facile',300,27,'image/pate-tomate-fromage.jpg'),(17,'Salade de Poulet Grill├®','Pr├®parez une salade fra├«che avec des morceaux de poulet grill├®, tomates, concombres et vinaigrette.',20,'Facile',300,NULL,'image/salade-poulet.jpg'),(18,'Spaghetti Bolognaise','Cuisinez des spaghettis avec une sauce bolognaise savoureuse. Garnissez de parmesan.',30,'Moyen',350,NULL,'image/pate-bolo.jpg'),(19,'Tacos au Poulet','Pr├®parez des tacos au poulet avec des l├®gumes frais, salsa et guacamole.',25,'Facile',250,NULL,'image/tacos-poulet.jpg'),(20,'Riz Cantonais','Faites cuire du riz avec des l├®gumes saut├®s, du jambon et des ┼ôufs pour un plat d├®licieux.',25,'Moyen',400,NULL,'image/riz-cantonais.jpg'),(21,'Omelette au Fromage','Battez des ┼ôufs, ajoutez du fromage et faites cuire une omelette moelleuse.',15,'Facile',200,NULL,'image/omelette-fromage.jpg'),(22,'Wraps aux L├®gumes','Pr├®parez des wraps sains avec des l├®gumes vari├®s, du poulet grill├® et de la sauce au yaourt.',20,'Facile',300,NULL,'image/wrap-legume.jpg'),(23,'Poulet au Citron','Cuisinez des morceaux de poulet avec une sauce au citron l├®g├¿re. Servez avec du riz.',30,'Moyen',400,NULL,'image/poulet-citron.jpg'),(24,'Salade de Quinoa','Faites une salade nutritive avec du quinoa, des l├®gumes, des herbes et une vinaigrette l├®g├¿re.',20,'Facile',250,NULL,'image/salade-quinoa.jpg'),(25,'P├ótes Alfredo aux Brocolis','Cuisinez des p├ótes Alfredo cr├®meuses avec des morceaux de brocolis. Ajoutez du parmesan.',25,'Moyen',350,NULL,'image/pate-brocoli.jpg'),(26,'Poulet au Curry Doux','Pr├®parez du poulet au curry doux avec du lait de coco, des l├®gumes et du riz basmati.',35,'Moyen',450,NULL,'image/poulet-curry-doux.jpg');
/*!40000 ALTER TABLE `recette` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recetteavalider`
--

DROP TABLE IF EXISTS `recetteavalider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recetteavalider` (
  `id` int NOT NULL,
  `nom` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `tempsPreparation` int DEFAULT NULL,
  `difficulte` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recetteavalider`
--

LOCK TABLES `recetteavalider` WRITE;
/*!40000 ALTER TABLE `recetteavalider` DISABLE KEYS */;
INSERT INTO `recetteavalider` VALUES (2,'hfdddd','jgjjhjkkj',45,'Moyen'),(1,'gh','kl',45,'Facile');
/*!40000 ALTER TABLE `recetteavalider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ustensile`
--

DROP TABLE IF EXISTS `ustensile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ustensile` (
  `identifiant` int NOT NULL,
  `libelle` varchar(50) NOT NULL,
  PRIMARY KEY (`identifiant`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ustensile`
--

LOCK TABLES `ustensile` WRITE;
/*!40000 ALTER TABLE `ustensile` DISABLE KEYS */;
INSERT INTO `ustensile` VALUES (1,'Po├¬le'),(2,'Mixeur'),(3,'Couteau'),(4,'Plat de cuisson'),(5,'Moule ├á g├óteau');
/*!40000 ALTER TABLE `ustensile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(50) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `mdp` text NOT NULL,
  `date_creation` datetime NOT NULL,
  `date_connexion` datetime NOT NULL,
  `role` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateur`
--

LOCK TABLES `utilisateur` WRITE;
/*!40000 ALTER TABLE `utilisateur` DISABLE KEYS */;
INSERT INTO `utilisateur` VALUES (33,'root','educook11@gmail.com','$2y$10$ODFoTcECtQJBGh7QPeB/0e.ZG3hOYmZL6QfGjPz.P/BuCPManTjfG','2024-03-11 03:19:23','2024-03-11 03:19:23',1);
/*!40000 ALTER TABLE `utilisateur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utiliser`
--

DROP TABLE IF EXISTS `utiliser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utiliser` (
  `identifiantR` int NOT NULL,
  `identifiantU` int NOT NULL,
  PRIMARY KEY (`identifiantR`,`identifiantU`),
  KEY `identifiantU` (`identifiantU`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utiliser`
--

LOCK TABLES `utiliser` WRITE;
/*!40000 ALTER TABLE `utiliser` DISABLE KEYS */;
INSERT INTO `utiliser` VALUES (1,1),(4,2),(5,3),(6,4),(7,5),(8,1),(9,2),(10,3),(11,4),(12,5),(13,1);
/*!40000 ALTER TABLE `utiliser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video` (
  `identifiant` int NOT NULL,
  `duree` int NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`identifiant`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES (1,60,'http'),(2,60,'http'),(3,60,'http'),(4,60,'http'),(5,60,'http'),(6,60,'http'),(7,60,'http'),(8,60,'http'),(9,60,'http'),(10,60,'http'),(11,60,'http');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-13 10:00:27
